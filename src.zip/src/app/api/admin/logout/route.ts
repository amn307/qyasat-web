import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    ok: true,
    message: "Client should clear local token.",
  });
}

export async function POST() {
  return NextResponse.json({
    ok: true,
    message: "Client should clear local token.",
  });
}
