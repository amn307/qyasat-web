import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://qyasat.sa";
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/admin/", "/api/admin/"] }],
    sitemap: `${siteUrl}/sitemap.xml`,
    host: siteUrl,
  };
}
